#!/usr/bin/env python3
from __future__ import annotations

import argparse
import getpass
import hashlib
import http.server
import json
import ipaddress
import os
import re
import socket
import struct
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.request
from datetime import datetime
from pathlib import Path
from xml.sax.saxutils import escape as xml_escape

import firmware_builder

DEVICE_IP = "192.168.1.1"
SERVICE_PORT = 30300
OTA_PORT = 80
EXPECTED_MODEL = b"LGU+-TAP-HW002"
SOFTAP_PREFIX = "TONLY_TAP_"
DEFAULT_FWR = "comMTTL-W01_1.0.111_UP_CHILDLOCK_OTA49217.fwr"
KNOWN_FIRMWARE_SHA256 = {
    DEFAULT_FWR: "7766d8c309ea77361a31b2af0c710ee24d05d076a48ecc0c8ee9b627bb288dfb",
    "comMTTL-W01_1.0.110_UP.fwr": "318f44567cd90613a3a485a66bb398c80bc60c891699772d438c9cfd6cb33059",
    "comMTTL-W01_1.0.66_LGU.fwr": "d780b578af69d52f3a05191a8e7d91a20e05085a912722327481cd5663682c04",
}
VERSION_FILES = {"111":DEFAULT_FWR,"110":"comMTTL-W01_1.0.110_UP.fwr","66":"comMTTL-W01_1.0.66_LGU.fwr"}
XOR_KEYS = {
    b"\xff" * 8: bytes.fromhex("3f5a27e8d8fb85f9bd4d51196c4f5159"),
    b"81958711": bytes.fromhex("3f5a27e8d8fb85f97c8397d3ad879f97"),
}


class InstallError(RuntimeError):
    pass


class ProvisionPending(RuntimeError):
    """OTA completed, but SoftAP/provisioning must be resumed manually."""
    pass


class _Tee:
    def __init__(self, *streams):
        self.streams = streams

    def write(self, data):
        for stream in self.streams:
            stream.write(data)
            stream.flush()
        return len(data)

    def flush(self):
        for stream in self.streams:
            stream.flush()

    def isatty(self):
        return bool(self.streams and getattr(self.streams[0], "isatty", lambda: False)())


_LOG_FILE = None
_ORIG_STDOUT = None
_ORIG_STDERR = None


def start_log(root: Path, command: str) -> Path:
    global _LOG_FILE, _ORIG_STDOUT, _ORIG_STDERR
    log_dir = root / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    path = log_dir / f"{command.replace('-', '_')}_{stamp}.log"
    _LOG_FILE = path.open("a", encoding="utf-8", buffering=1)
    _ORIG_STDOUT, _ORIG_STDERR = sys.stdout, sys.stderr
    sys.stdout = _Tee(_ORIG_STDOUT, _LOG_FILE)
    sys.stderr = _Tee(_ORIG_STDERR, _LOG_FILE)
    print(f"[{datetime.now():%Y-%m-%d %H:%M:%S}] === MTTL-W01 {command} start ===")
    print(f"[LOG] {path}")
    return path



def stop_log() -> None:
    global _LOG_FILE, _ORIG_STDOUT, _ORIG_STDERR
    # Restore console streams before closing the log. This avoids Python's final
    # stdout/stderr flush touching an already-closed Tee target (Windows exit 120).
    if _ORIG_STDOUT is not None:
        sys.stdout = _ORIG_STDOUT
    if _ORIG_STDERR is not None:
        sys.stderr = _ORIG_STDERR
    if _LOG_FILE is not None:
        try:
            _LOG_FILE.flush()
            _LOG_FILE.close()
        except Exception:
            pass
    _LOG_FILE = None
    _ORIG_STDOUT = None
    _ORIG_STDERR = None

def local_ip_for(target: str = DEVICE_IP) -> str:
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect((target, 9))
        return s.getsockname()[0]
    finally:
        s.close()


def reachable(host: str, port: int, timeout: float = 1.0) -> bool:
    try:
        with socket.create_connection((host, port), timeout):
            return True
    except OSError:
        return False


def build_official_from_source(folder: Path, version: str) -> Path:
    version=str(version)
    if version not in VERSION_FILES:raise InstallError("생성 버전은 111/110/66 중 하나여야 합니다")
    try:path=firmware_builder.build_version(folder,version)
    except Exception as exc:raise InstallError(f"1.0.105/LG U+ 1.0.66 source 기반 {version} 생성 실패: {exc}")
    expected=KNOWN_FIRMWARE_SHA256[VERSION_FILES[version]];actual=hashlib.sha256(path.read_bytes()).hexdigest()
    if actual!=expected:raise InstallError(f"생성 FWR SHA256 불일치: {actual}")
    return path


def build_all_official_from_source(folder: Path) -> list[Path]:
    return [build_official_from_source(folder,v) for v in ("66","110","111")]


def choose_fwr(folder: Path) -> Path:
    files = sorted((p for p in folder.glob("*.fwr") if p.is_file()), key=lambda p: p.name.lower())
    if not files:
        raise InstallError(f"FWR 파일이 없습니다: {folder}")
    if len(files) == 1:
        print(f"[FWR] {files[0].name}")
        return files[0]
    print("사용할 FWR 파일을 선택하세요:")
    for i, p in enumerate(files, 1):
        print(f"  {i}. {p.name}")
    while True:
        try:
            n = int(input(f"Select firmware [1-{len(files)}]: ").strip())
            if 1 <= n <= len(files):
                print(f"[FWR] {files[n - 1].name}")
                return files[n - 1]
        except ValueError:
            pass
        print("잘못된 선택입니다.")


def load_and_decode_fwr(path: Path) -> bytes:
    raw = path.read_bytes()
    if len(raw) != 327944:
        raise InstallError(f"예상하지 못한 FWR 크기: {len(raw)}")
    marker = raw[8:16]
    key = XOR_KEYS.get(marker)
    if key is None:
        raise InstallError(f"지원하지 않는 FWR marker: {marker.hex()}")
    plain = bytearray(raw)
    for i in range(16, len(plain)):
        plain[i] ^= key[(i - 16) & 15]
    declared, base = struct.unpack_from("<II", plain, 0)
    if declared != 0x500F4 or base != 0x10006000:
        raise InstallError(f"FWR header 불일치: size={declared:#x} base={base:#x}")
    if bytes(plain[40:40 + len(EXPECTED_MODEL)]) != EXPECTED_MODEL:
        raise InstallError("ota.bin model field 불일치")
    stored = struct.unpack_from("<I", plain, len(plain) - 4)[0]
    calc = sum(plain[:-4]) & 0xFFFFFFFF
    if stored != calc:
        raise InstallError(f"ota.bin checksum 불일치: stored={stored:08x} calc={calc:08x}")
    return bytes(plain)


def _safe_command(command: str) -> str:
    if command.lower().startswith("up:connect:"):
        parts = command.split(":", 2)
        ssid = parts[2].split(":", 1)[0] if len(parts) > 2 else "?"
        return f"up:connect:{ssid}:<password-redacted>"
    return command


def send_up(command: str, expect: str | None = None, timeout: float = 4.0) -> str:
    payload = (command.rstrip("\r\n") + "\r\n").encode("utf-8")
    with socket.create_connection((DEVICE_IP, SERVICE_PORT), timeout=timeout) as s:
        s.settimeout(timeout)
        s.sendall(payload)
        buf = b""
        deadline = time.time() + timeout
        while time.time() < deadline:
            try:
                chunk = s.recv(1024)
            except socket.timeout:
                break
            if not chunk:
                break
            buf += chunk
            if b"\n" in buf:
                break
    text = buf.decode("utf-8", "replace").strip()
    if expect and expect not in text:
        raise InstallError(
            f"장치 응답 불일치: sent={_safe_command(command)!r} expected={expect!r} got={text!r}"
        )
    return text


class _OtaHTTPServer(http.server.ThreadingHTTPServer):
    allow_reuse_address = True
    daemon_threads = True

    def __init__(self, addr, handler, ota: bytes, done: threading.Event):
        self.ota = ota
        self.done = done
        self.error: str | None = None
        super().__init__(addr, handler)


class _OtaHandler(http.server.BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        print("[HTTP] " + fmt % args)

    def do_GET(self):
        if self.path != "/ota.bin":
            self.send_error(404)
            return
        data = self.server.ota
        sent = 0
        try:
            self.send_response(200)
            self.send_header("Content-Type", "application/octet-stream")
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Connection", "close")
            self.end_headers()
            for i in range(0, len(data), 512):
                chunk = data[i:i + 512]
                self.wfile.write(chunk)
                self.wfile.flush()
                sent += len(chunk)
                if sent % (64 * 1024) == 0 or sent == len(data):
                    print(f"[OTA] sent {sent}/{len(data)} bytes")
                time.sleep(0.005)
            self.server.done.set()
            print(f"[OTA] /ota.bin wire transfer complete: {sent} bytes")
        except (ConnectionResetError, BrokenPipeError, ConnectionAbortedError) as exc:
            self.server.error = f"{type(exc).__name__} after {sent}/{len(data)} bytes: {exc}"
            self.server.done.set()
            print(f"[OTA] device closed HTTP connection after {sent}/{len(data)} bytes: {exc}")
        except Exception as exc:
            self.server.error = f"{type(exc).__name__} after {sent}/{len(data)} bytes: {exc}"
            self.server.done.set()
            print(f"[OTA] HTTP error after {sent}/{len(data)} bytes: {exc}")


def preflight(fwr: Path, require_port80: bool = True) -> dict:
    if not fwr.exists():
        raise InstallError(f"펌웨어 파일 없음: {fwr}")
    load_and_decode_fwr(fwr)
    if not reachable(DEVICE_IP, SERVICE_PORT):
        raise InstallError(f"{DEVICE_IP}:{SERVICE_PORT} 연결 실패. MTTL의 TONLY_TAP_* SoftAP에 연결하세요.")
    lip = local_ip_for()
    try:
        ip = ipaddress.ip_address(lip)
    except ValueError:
        raise InstallError(f"Invalid local IPv4 address: {lip}")
    if ip.version != 4:
        raise InstallError(f"IPv4 is required for local OTA: {lip}")
    if require_port80:
        s = socket.socket()
        try:
            s.bind(("0.0.0.0", OTA_PORT))
        except OSError as exc:
            raise InstallError(
                f"TCP/80 bind failed: {exc}. 다른 HTTP 서버를 종료하세요. Windows는 관리자 권한, macOS/Linux는 sudo 실행이 필요할 수 있습니다."
            )
        finally:
            s.close()
    wire = fwr.read_bytes()
    return {"local_ip": lip, "device": f"{DEVICE_IP}:{SERVICE_PORT}", "wire_bytes": len(wire)}


def windows_firewall_add() -> bool:
    if os.name!="nt":return False
    rule="MTTL-W01 OTA TCP80"
    try:
        subprocess.run(["netsh","advfirewall","firewall","delete","rule",f"name={rule}"],capture_output=True,timeout=15)
        cp=subprocess.run(["netsh","advfirewall","firewall","add","rule",f"name={rule}","dir=in","action=allow","protocol=TCP","localport=80",f"remoteip={DEVICE_IP}","profile=any"],capture_output=True,text=True,errors="replace",timeout=15)
        if cp.returncode==0:
            print("[FIREWALL] temporary TCP/80 rule added")
            return True
        print(f"[FIREWALL] WARN: temporary rule add failed (code={cp.returncode}); 관리자 권한이면 자동 처리됩니다")
    except Exception as exc:
        print(f"[FIREWALL] WARN: {exc}")
    return False


def windows_firewall_remove() -> None:
    if os.name!="nt":return
    rule="MTTL-W01 OTA TCP80"
    try:
        subprocess.run(["netsh","advfirewall","firewall","delete","rule",f"name={rule}"],capture_output=True,timeout=15)
        print("[FIREWALL] temporary TCP/80 rule removed")
    except Exception:
        pass

def run_ota(fwr: Path, serve_timeout: float = 90.0, softap_ssid: str | None = None) -> None:
    fw_added=windows_firewall_add()
    try:
        try:
            info = preflight(fwr, True)
        except InstallError as exc:
            # Wi-Fi can roam back to the home AP between discovery and OTA start. Recover once interactively.
            if not reachable(DEVICE_IP, SERVICE_PORT, 1.0):
                softap_ssid = manual_softap_fallback(softap_ssid, reason=f"OTA 시작 직전 장치 연결 확인 실패: {exc}")
                info = preflight(fwr, True)
            else:
                raise
        print("[OK] preflight", info)
        # Device expects the original encrypted .fwr on HTTP. Decoding above is validation only.
        ota = fwr.read_bytes()
        done = threading.Event()
        server = _OtaHTTPServer(("0.0.0.0", OTA_PORT), _OtaHandler, ota, done)
        th = threading.Thread(target=server.serve_forever, daemon=True)
        th.start()
        try:
            ota_host = info["local_ip"]
            print(f"[OTA] waiting for http://{ota_host}/ota.bin")
            resp = send_up(f"up:ota:{ota_host}", expect="up:ota:ota_ok", timeout=5.0)
            print("[OTA] trigger ACK:", resp)
            if not done.wait(serve_timeout):
                hint = " Windows에서는 관리자 권한, macOS/Linux에서는 TCP/80 bind를 위해 sudo 실행을 확인하세요."
                raise InstallError(f"Device acknowledged OTA server {ota_host} but did not request /ota.bin." + hint)
            if server.error:
                raise InstallError(f"OTA HTTP 전송 오류: {server.error}")
            print("[OTA] encrypted .fwr transfer completed. 장치 내부 검증/flash 동안 전원을 유지하세요.")
        finally:
            server.shutdown()
            server.server_close()
            th.join(timeout=2)
    finally:
        if os.name=="nt":windows_firewall_remove()

def validate_backend_ip(value: str) -> str:
    try:
        ip = ipaddress.ip_address(value)
    except ValueError:
        raise InstallError("backend IP는 IPv4 주소여야 합니다")
    if ip.version != 4 or ip.is_unspecified or ip.is_multicast:
        raise InstallError("사용할 수 없는 backend IPv4입니다")
    return str(ip)


def validate_wifi(ssid: str, password: str) -> None:
    if not 1 <= len(ssid.encode()) <= 32:
        raise InstallError("SSID 길이는 1~32 bytes여야 합니다")
    if ":" in ssid or "\r" in ssid or "\n" in ssid:
        raise InstallError("현재 up:connect 프로토콜은 SSID에 ':'/개행을 사용할 수 없습니다")
    if ":" in password or "\r" in password or "\n" in password:
        raise InstallError("현재 up:connect 프로토콜은 비밀번호에 ':'/개행을 사용할 수 없습니다")


def softap_mac_suffix(softap_ssid: str | None) -> str | None:
    m=re.match(r'^TONLY_TAP_([0-9A-Fa-f]+)$',str(softap_ssid or '').strip(),re.I)
    if not m:return None
    suffix=m.group(1).lower()
    return suffix if 4<=len(suffix)<=12 else None


def read_device_info_mac() -> str | None:
    """Read exact device MAC from stock-compatible LGAPMODE cmd103 before up:connect tears SoftAP down."""
    try:
        with socket.create_connection((DEVICE_IP,SERVICE_PORT),timeout=5.0) as sock:
            sock.settimeout(6.0);sock.sendall(build_lgapmode_command(103))
            header=_recv_exact(sock,20)
            if header[:12]!=b'LGAPMODE0010':raise InstallError('cmd103 header mismatch')
            response_code,body_size=struct.unpack_from('<II',header,12)
            # Request code is 103; canonical MTTL-W01 response code is 20301 (0x4F4D)
            # with a 70-byte body. The original LG parser validates the body, not an echo.
            if not 68<=body_size<=512:raise InstallError(f'cmd103 response mismatch code={response_code} size={body_size}')
            body=_recv_exact(sock,body_size)
            result=struct.unpack_from('<I',body,body_size-4)[0]
            if result!=0:raise InstallError(f'cmd103 result={result}')
            model=body[48:64].split(b'\0',1)[0].decode('ascii','ignore').strip()
            if model!='MTTL-W01':raise InstallError(f'cmd103 model invalid: {model!r} code={response_code}')
            mac=re.sub(r'[^0-9A-Fa-f]','',body[:12].decode('ascii','ignore')).lower()
            if len(mac)!=12:raise InstallError(f'cmd103 MAC invalid: {mac!r}')
            return mac
    except Exception as exc:
        print(f'[DEVICE INFO] WARN: exact MAC read skipped: {exc}')
        return None


def wait_backend_attach(backend_ip: str, softap_ssid: str | None, timeout: float = 75.0, web_port: int | None = None, exact_mac: str | None = None) -> dict | None:
    suffix=softap_mac_suffix(softap_ssid);exact_mac=re.sub(r'[^0-9A-Fa-f]','',str(exact_mac or '')).lower()
    if len(exact_mac)!=12:exact_mac=''
    if web_port is None:
        try:web_port=int(os.getenv('MTTL_UP_WEB_PORT','18282'))
        except ValueError:raise InstallError('MTTL_UP_WEB_PORT는 유효한 TCP port 숫자여야 합니다')
    if not 1<=int(web_port)<=65535:raise InstallError('MTTL_UP_WEB_PORT 범위가 올바르지 않습니다')
    hint=f'MAC={exact_mac}' if exact_mac else f'MAC suffix={suffix}' if suffix else 'device-id unavailable'
    if not exact_mac and not suffix:
        print('[VERIFY] WARN: 장치 식별값이 없어 backend attach 자동 확인은 생략합니다. up:connect ACK는 정상 수락됐습니다.')
        return None
    url=f'http://{backend_ip}:{int(web_port)}/api/devices'
    deadline=time.time()+max(1.0,float(timeout)); last_note=0.0; last_error=None
    print(f'[VERIFY] backend attach 대기: {url} / {hint}')
    while time.time()<deadline:
        try:
            with urllib.request.urlopen(url,timeout=2.0) as r:body=json.loads(r.read().decode('utf-8','replace'))
            for d in body.get('devices') or []:
                mac=re.sub(r'[^0-9A-Fa-f]','',str(d.get('mac') or '')).lower()
                match=mac==exact_mac if exact_mac else mac.endswith(suffix or '___never___')
                if match and d.get('online') is True:
                    print(f'[VERIFY] TCP10086 backend attach 확인: mac={mac} fw={d.get("firmware_version") or "?"}')
                    return d
            last_error='device not online yet'
        except Exception as exc:last_error=f'{type(exc).__name__}: {exc}'
        if time.time()-last_note>=5.0:print(f'[VERIFY] backend 재접속 대기 중... {last_error}');last_note=time.time()
        time.sleep(1.0)
    print(f'[VERIFY] WARN: 프로비저닝 명령은 정상 수락됐지만 {timeout:g}초 내 backend attach 확인을 완료하지 못했습니다 ({hint}). 실제 Backend에 online이면 성공입니다.')
    return None


def _fixed_field(value: str, encoding: str, size: int = 32) -> bytes:
    try:
        raw=value.encode(encoding)
    except UnicodeEncodeError as exc:
        raise InstallError(f"{encoding}로 표현할 수 없는 Wi-Fi 문자열입니다: {exc}")
    if len(raw)>size:
        raise InstallError(f"Wi-Fi 문자열이 {encoding} 기준 {size} bytes를 초과합니다")
    return raw.ljust(size,b"\0")


def build_lgapmode_wifi_packet(ssid: str,password: str) -> bytes:
    """Exact MTTL-W01 stock/Voltra SoftAP cmd101 frame: 20-byte LE header + 128-byte body."""
    if not ssid:raise InstallError("SSID는 비어 있을 수 없습니다")
    body=(
        _fixed_field(ssid,"euc_kr")+
        _fixed_field(password,"euc_kr")+
        _fixed_field(ssid,"utf-8")+
        _fixed_field(password,"utf-8")
    )
    return b"LGAPMODE0010"+struct.pack("<II",101,len(body))+body


def build_lgapmode_command(command: int) -> bytes:
    return b"LGAPMODE0010"+struct.pack("<II",int(command),0)


def _recv_exact(sock: socket.socket,size: int) -> bytes:
    buf=bytearray()
    while len(buf)<size:
        chunk=sock.recv(size-len(buf))
        if not chunk:raise InstallError(f"LGAPMODE 응답이 중간에 종료되었습니다 ({len(buf)}/{size})")
        buf.extend(chunk)
    return bytes(buf)


def recv_lgapmode_response(sock: socket.socket,expected_command: int) -> tuple[int,bytes]:
    header=_recv_exact(sock,20)
    if header[:12]!=b"LGAPMODE0010":raise InstallError(f"LGAPMODE 응답 header 불일치: {header[:12]!r}")
    command,body_size=struct.unpack_from("<II",header,12)
    if command!=expected_command:raise InstallError(f"LGAPMODE 응답 command 불일치: expected={expected_command} got={command}")
    if body_size>4096:raise InstallError(f"LGAPMODE 응답 body size 비정상: {body_size}")
    body=_recv_exact(sock,body_size) if body_size else b""
    result=struct.unpack_from("<I",body,0)[0] if len(body)>=4 else 0
    if result!=0:raise InstallError(f"LGAPMODE command {expected_command} result={result}")
    return result,body


def validate_generic_wifi(ssid: str,password: str) -> None:
    # Build once to enforce the real 32-byte EUC-KR + UTF-8 field constraints.
    build_lgapmode_wifi_packet(ssid,password)


def provision_generic(ssid: str, password: str, softap_ssid: str | None = None) -> None:
    """Stock-compatible provisioning using the confirmed LGAPMODE binary 101/102 protocol."""
    validate_generic_wifi(ssid,password)
    if not reachable(DEVICE_IP,SERVICE_PORT):
        softap_ssid = manual_softap_fallback(softap_ssid, reason="Generic Provision 시작 직전 SoftAP 연결이 끊겼습니다")
        if not reachable(DEVICE_IP,SERVICE_PORT):
            raise InstallError("SoftAP 복구 후에도 장치 서비스에 도달하지 못했습니다")
    print("[PROVISION:GENERIC] 표준 LGAPMODE 프로비저닝: cmd101 Wi-Fi -> cmd102 reset/apply")
    print("[PROVISION:GENERIC] up:ip / UP backend 설정은 사용하지 않습니다.")
    packet=build_lgapmode_wifi_packet(ssid,password)
    with socket.create_connection((DEVICE_IP,SERVICE_PORT),timeout=7.0) as sock:
        sock.settimeout(7.0)
        print(f"[PROVISION:GENERIC] Wi-Fi 저장: SSID={ssid} / password=<redacted> / body=128")
        sock.sendall(packet)
        recv_lgapmode_response(sock,201)
        print("[PROVISION:GENERIC] cmd201 result=0 확인")
        sock.sendall(build_lgapmode_command(102))
        recv_lgapmode_response(sock,202)
        print("[PROVISION:GENERIC] cmd202 result=0 확인")
    print("[PROVISION:GENERIC] 완료: 표준 Wi-Fi provisioning + reset/apply 성공.")


def provision_up(backend_ip: str, ssid: str, password: str, softap_ssid: str | None = None, verify_attach: bool = True) -> None:
    """Provision UP backend + final Wi-Fi, then verify the device really attached to UP."""
    backend_ip=validate_backend_ip(backend_ip)
    validate_wifi(ssid,password)
    if not reachable(DEVICE_IP,SERVICE_PORT):
        softap_ssid = manual_softap_fallback(softap_ssid, reason="UP Provision 시작 직전 SoftAP 연결이 끊겼습니다")
        if not reachable(DEVICE_IP,SERVICE_PORT):
            raise InstallError("SoftAP 복구 후에도 장치 서비스에 도달하지 못했습니다")
    exact_mac=read_device_info_mac()
    if exact_mac:print(f"[PROVISION:UP] Device Info exact MAC: {exact_mac}")
    print(f"[PROVISION:UP] backend IP 저장: {backend_ip}")
    print(" ",send_up(f"up:ip:{backend_ip}",expect="up:ip:ip_ok",timeout=5.0))
    print(f"[PROVISION:UP] 최종 Wi-Fi 저장/적용: SSID={ssid} / password=<redacted>")
    # connect_ok proves command acceptance only; actual UP attachment is verified below.
    print(" ",send_up(f"up:connect:{ssid}:{password}",expect="up:connect:connect_ok",timeout=6.0))
    print("[PROVISION:UP] 명령 수락 완료. 실제 TCP10086 backend 재접속을 확인합니다.")
    if verify_attach:
        attached=wait_backend_attach(backend_ip,softap_ssid,exact_mac=exact_mac)
        if attached:print("[PROVISION:UP] 완료: 최종 Wi-Fi + backend TCP10086 연결 확인됨.")
        else:print("[PROVISION:UP] 완료: up:ip/up:connect ACK 정상. Backend attach는 자동 확인 미완료(경고만).")
    else:
        print("[PROVISION:UP] 경고: backend attach 검증을 생략했습니다.")


# Backward-compatible internal name used by install/all paths.
def final_provision(backend_ip: str, ssid: str, password: str, softap_ssid: str | None = None, verify_attach: bool = True) -> None:
    provision_up(backend_ip,ssid,password,softap_ssid,verify_attach)


def parse_windows_netsh_networks(text: str) -> list[dict]:
    """Parse netsh WLAN output without depending on localized signal labels."""
    networks = []
    current = None
    for raw in str(text or "").splitlines():
        line = raw.strip()
        m = re.match(r"^SSID\s+\d+\s*:\s*(.*)$", line, re.I)
        if m:
            current = {"ssid": m.group(1).strip(), "signal": -1}
            networks.append(current)
            continue
        if current is not None:
            m = re.search(r"(\d{1,3})\s*%", line)
            if m:
                current["signal"] = max(current["signal"], min(100, int(m.group(1))))
    return networks


def softap_password(ssid: str) -> str | None:
    m = re.match(r"^TONLY_TAP_(.+)$", str(ssid or ""), re.I)
    return f"LGU_{m.group(1)}" if m else None


def windows_current_ssid() -> str | None:
    if os.name != "nt":
        return None
    try:
        cp = subprocess.run(
            ["netsh", "wlan", "show", "interfaces"],
            capture_output=True, text=True, errors="replace", timeout=10
        )
    except Exception:
        return None
    text = (cp.stdout or "") + "\n" + (cp.stderr or "")
    for raw in text.splitlines():
        m = re.match(r"^\s*SSID\s*:\s*(.+?)\s*$", raw, re.I)
        if m:
            return m.group(1).strip()
    return None


def linux_current_ssid() -> str | None:
    try:
        cp = subprocess.run(["nmcli", "-t", "-f", "ACTIVE,SSID", "dev", "wifi"], capture_output=True, text=True, errors="replace", timeout=10)
        for line in (cp.stdout or "").splitlines():
            if line.startswith("yes:"):
                return line.split(":", 1)[1].replace("\\:", ":")
    except Exception:
        pass
    return None


def macos_wifi_device() -> str | None:
    try:
        cp = subprocess.run(["/usr/sbin/networksetup", "-listallhardwareports"], capture_output=True, text=True, errors="replace", timeout=10)
        lines=(cp.stdout or "").splitlines()
        for i,line in enumerate(lines):
            if "Wi-Fi" in line or "AirPort" in line:
                for j in range(i+1,min(i+4,len(lines))):
                    m=re.match(r"^Device:\s*(\S+)",lines[j].strip())
                    if m:return m.group(1)
    except Exception:
        pass
    return None


def macos_current_ssid() -> str | None:
    dev=macos_wifi_device()
    if not dev:return None
    try:
        cp=subprocess.run(["/usr/sbin/networksetup","-getairportnetwork",dev],capture_output=True,text=True,errors="replace",timeout=10)
        text=((cp.stdout or "")+"\n"+(cp.stderr or "")).strip()
        m=re.search(r":\s*(.+)$",text)
        if m and "not associated" not in m.group(1).lower():return m.group(1).strip()
    except Exception:
        pass
    return None


def current_ssid() -> str | None:
    if os.name=="nt":return windows_current_ssid()
    if sys.platform.startswith("linux"):return linux_current_ssid()
    if sys.platform=="darwin":return macos_current_ssid()
    return None


def wait_device_service(timeout: float = 60.0) -> bool:
    deadline=time.time()+timeout
    last=0.0
    while time.time()<deadline:
        if reachable(DEVICE_IP,SERVICE_PORT,1.0):
            print(f"[DEVICE] {DEVICE_IP}:{SERVICE_PORT} service ready")
            return True
        if time.time()-last>=5.0:
            print(f"[DEVICE] firmware 작업 중... {DEVICE_IP}:{SERVICE_PORT} 복귀 대기")
            last=time.time()
        time.sleep(1.0)
    return False


def provisioning_pending_message(softap_ssid: str | None = None) -> str:
    target = softap_ssid or "TONLY_TAP_*"
    return (
        "OTA는 완료됐지만 펌웨어 변경 폭이 큰 경우 재부팅 후 SoftAP가 자동 복귀하지 않을 수 있습니다.\n"
        "장치 전원 버튼을 길게 눌러 SoftAP 모드로 다시 진입한 뒤, PC를 " + target +
        " 에 연결하고 PROVISION_WINDOWS.bat 를 실행하세요.\n"
        "이 단계에서는 OTA를 다시 할 필요가 없습니다."
    )


def prompt_yes_no(message: str, default: bool = False) -> bool:
    suffix = " [Y/n]: " if default else " [y/N]: "
    while True:
        raw = input(message + suffix).strip().lower()
        if not raw:
            return default
        if raw in ("y", "yes", "예", "네"):
            return True
        if raw in ("n", "no", "아니오", "아니요"):
            return False
        print("y 또는 n으로 입력하세요.")


def _current_softap_name(expected: str | None = None) -> str | None:
    cur = current_ssid()
    if cur and cur.lower().startswith(SOFTAP_PREFIX.lower()):
        return cur
    if expected and re.match(r"^TONLY_TAP_.+$", expected, re.I):
        return expected
    return None


def _manual_softap_check(expected: str | None = None, wait_seconds: float = 8.0) -> str | None:
    cur = current_ssid()
    if cur:
        print(f"[WIFI] 현재 연결: {cur}")
    else:
        print("[WIFI] 현재 SSID를 OS에서 읽지 못했습니다. 장치 서비스로 직접 확인합니다.")

    candidate = cur if cur and cur.lower().startswith(SOFTAP_PREFIX.lower()) else expected
    if os.name == "nt":
        if not candidate:
            try:
                aps = windows_softap_scan()
                if len(aps) == 1:
                    candidate = aps[0]["ssid"]
                    print(f"[WIFI] 재검색에서 SoftAP 1개 발견: {candidate}; 자동 연결을 다시 시도합니다.")
                elif len(aps) > 1:
                    names = ", ".join(a["ssid"] for a in aps)
                    print(f"[WIFI] SoftAP가 여러 개 보입니다: {names}; Wi-Fi 설정에서 대상 장치를 선택하세요.")
            except Exception as exc:
                print(f"[WIFI] 재검색 경고: {exc}")
        if candidate and (not cur or cur.lower() != candidate.lower()):
            # The profile may already exist even when Windows scan/location access is restricted.
            try:
                print(f"[WIFI] 저장된 프로필로 {candidate} 연결을 한 번 더 시도합니다.")
                _netsh_connect_profile(candidate)
            except Exception as exc:
                print(f"[WIFI] 재연결 요청 경고: {exc}")

    deadline = time.time() + max(0.5, wait_seconds)
    while time.time() < deadline:
        cur = current_ssid()
        candidate = cur if cur and cur.lower().startswith(SOFTAP_PREFIX.lower()) else candidate
        if reachable(DEVICE_IP, SERVICE_PORT, 1.0):
            name = candidate or expected or "TONLY_TAP_*"
            print(f"[WIFI] SoftAP 확인 완료: {name} / {DEVICE_IP}:{SERVICE_PORT} reachable")
            return name
        time.sleep(0.5)
    return None


def manual_softap_fallback(expected: str | None = None, reason: str | None = None) -> str:
    print("\n[WIFI RECOVERY]")
    if reason:
        print(f"[WIFI] {reason}")
    if expected:
        print(f"Windows/macOS/Linux Wi-Fi 설정에서 {expected} 에 연결되어 있는지 확인하세요.")
        pw = softap_password(expected)
        if pw:
            print(f"처음 연결할 때 암호가 필요하면: {pw}")
    else:
        print("Wi-Fi 목록에서 TONLY_TAP_* 를 선택해 직접 연결하세요.")
        print("암호 규칙: TONLY_TAP_ABCDEF -> LGU_ABCDEF")
    print("'인터넷 없음'으로 표시되어도 연결을 유지하세요. SoftAP 이름을 직접 입력할 필요는 없습니다.")

    prompts = (
        "SoftAP에 연결했으면 Enter를 누르세요. 다시 확인합니다: ",
        "아직 확인되지 않았습니다. Wi-Fi가 TONLY_TAP_*인지 다시 확인한 뒤 Enter를 누르세요: ",
    )
    for prompt in prompts:
        input(prompt)
        found = _manual_softap_check(expected, 8.0)
        if found:
            return found
        print(f"[WIFI] 아직 {DEVICE_IP}:{SERVICE_PORT} 장치 서비스가 확인되지 않았습니다.")

    print("\n[WIFI] 자동/수동 확인을 두 번 수행했지만 장치 서비스를 확인하지 못했습니다.")
    print("Wi-Fi 설정에서 실제로 TONLY_TAP_* 에 연결되어 있는지 확인하세요.")
    if prompt_yes_no("그래도 다음 단계까지 진행해서 실제 장치 통신을 시도할까요?", default=False):
        candidate = _current_softap_name(expected) or "TONLY_TAP_*"
        print(f"[WIFI] 사용자 확인으로 계속 진행합니다: {candidate}")
        print("[WIFI] 실제 OTA/Provision 단계의 장치 응답 검증은 그대로 수행됩니다.")
        return candidate
    raise InstallError("SoftAP 연결을 확인하지 못해 사용자가 작업 종료를 선택했습니다")


def linux_softap_scan() -> list[dict]:
    try:
        cp=subprocess.run(["nmcli","-t","-f","SSID,SIGNAL","dev","wifi","list","--rescan","yes"],capture_output=True,text=True,errors="replace",timeout=15)
    except Exception:return []
    out=[]
    for line in (cp.stdout or "").splitlines():
        parts=line.rsplit(":",1)
        if len(parts)!=2:continue
        ssid=parts[0].replace("\\:",":");
        if ssid.lower().startswith(SOFTAP_PREFIX.lower()):
            try:sig=int(parts[1])
            except ValueError:sig=-1
            out.append({"ssid":ssid,"signal":sig})
    uniq={x["ssid"].lower():x for x in out}
    return sorted(uniq.values(),key=lambda x:(-x["signal"],x["ssid"].lower()))


def linux_connect_softap(ssid: str) -> None:
    pw=softap_password(ssid)
    if not pw:raise InstallError(f"SoftAP SSID 형식을 인식할 수 없습니다: {ssid}")
    cp=subprocess.run(["nmcli","dev","wifi","connect",ssid,"password",pw],capture_output=True,text=True,errors="replace",timeout=30)
    msg=((cp.stdout or "")+" "+(cp.stderr or "")).strip().replace("\n"," ")
    print(f"[WIFI] nmcli connect {ssid}: code={cp.returncode}"+(f" / {msg}" if msg else ""))
    if cp.returncode!=0 or not wait_device_service(15):raise InstallError(f"nmcli로 {ssid} 연결 실패")


def macos_connect_softap(ssid: str) -> None:
    dev=macos_wifi_device();pw=softap_password(ssid)
    if not dev or not pw:raise InstallError("macOS Wi-Fi 인터페이스 또는 SoftAP 암호를 확인할 수 없습니다")
    cp=subprocess.run(["/usr/sbin/networksetup","-setairportnetwork",dev,ssid,pw],capture_output=True,text=True,errors="replace",timeout=30)
    msg=((cp.stdout or "")+" "+(cp.stderr or "")).strip().replace("\n"," ")
    print(f"[WIFI] networksetup connect {ssid}: code={cp.returncode}"+(f" / {msg}" if msg else ""))
    if cp.returncode!=0 or not wait_device_service(15):raise InstallError(f"networksetup으로 {ssid} 연결 실패")

def windows_softap_scan() -> list[dict]:
    if os.name != "nt":
        raise InstallError("SoftAP 자동 검색은 Windows에서만 지원합니다")
    merged: dict[str, dict] = {}
    errors = []
    for args in (["netsh", "wlan", "show", "networks", "mode=bssid"], ["netsh", "wlan", "show", "networks"]):
        try:
            cp = subprocess.run(args, capture_output=True, text=True, errors="replace", timeout=15)
        except Exception as exc:
            errors.append(str(exc))
            continue
        text = (cp.stdout or "") + "\n" + (cp.stderr or "")
        if cp.returncode != 0:
            errors.append(f"netsh code={cp.returncode}")
            continue
        for item in parse_windows_netsh_networks(text):
            ssid = item["ssid"]
            if not ssid.lower().startswith(SOFTAP_PREFIX.lower()):
                continue
            old = merged.get(ssid.lower())
            if old is None or item["signal"] > old["signal"]:
                merged[ssid.lower()] = item
    result = sorted(merged.values(), key=lambda x: (-x["signal"], x["ssid"].lower()))
    if not result and errors:
        print("[WIFI] scan notes: " + "; ".join(errors))
    return result


def _wlan_profile_xml(ssid: str, password: str) -> str:
    s = xml_escape(ssid)
    p = xml_escape(password)
    return f'''<?xml version="1.0"?>
<WLANProfile xmlns="http://www.microsoft.com/networking/WLAN/profile/v1">
  <name>{s}</name>
  <SSIDConfig><SSID><name>{s}</name></SSID></SSIDConfig>
  <connectionType>ESS</connectionType>
  <connectionMode>manual</connectionMode>
  <MSM><security>
    <authEncryption><authentication>WPA2PSK</authentication><encryption>AES</encryption><useOneX>false</useOneX></authEncryption>
    <sharedKey><keyType>passPhrase</keyType><protected>false</protected><keyMaterial>{p}</keyMaterial></sharedKey>
  </security></MSM>
</WLANProfile>
'''


def _netsh_connect_profile(ssid: str) -> None:
    cp = subprocess.run(
        ["netsh", "wlan", "connect", f"name={ssid}", f"ssid={ssid}"],
        capture_output=True, text=True, errors="replace", timeout=15
    )
    msg = ((cp.stdout or "") + " " + (cp.stderr or "")).strip().replace("\r", " ").replace("\n", " ")
    print(f"[WIFI] netsh connect {ssid}: code={cp.returncode}" + (f" / {msg}" if msg else ""))


def _install_softap_profile(ssid: str) -> None:
    password = softap_password(ssid)
    if not password:
        raise InstallError(f"SoftAP SSID 형식을 인식할 수 없습니다: {ssid}")
    fd, temp_name = tempfile.mkstemp(prefix="mttl_wlan_", suffix=".xml", text=True)
    os.close(fd)
    try:
        Path(temp_name).write_text(_wlan_profile_xml(ssid, password), encoding="utf-8")
        cp = subprocess.run(
            ["netsh", "wlan", "add", "profile", f"filename={temp_name}", "user=current"],
            capture_output=True, text=True, errors="replace", timeout=15
        )
        msg = ((cp.stdout or "") + " " + (cp.stderr or "")).strip().replace("\r", " ").replace("\n", " ")
        if cp.returncode != 0:
            raise InstallError(f"Wi-Fi 프로필 생성 실패(code={cp.returncode}): {msg}")
        print(f"[WIFI] profile ready: {ssid} / password=<derived-and-redacted>")
    finally:
        try:
            os.unlink(temp_name)
        except OSError:
            pass


def _wait_device_reachable(expected_ssid: str, timeout: float) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        current = windows_current_ssid()
        if current and current.lower() == expected_ssid.lower() and reachable(DEVICE_IP, SERVICE_PORT, 1.0):
            print(f"[WIFI] connected: {current} / device {DEVICE_IP}:{SERVICE_PORT} reachable")
            return True
        time.sleep(1.0)
    return False


def windows_connect_softap(ssid: str, timeout: float = 25.0) -> None:
    current = windows_current_ssid()
    if current and current.lower() == ssid.lower() and reachable(DEVICE_IP, SERVICE_PORT, 1.0):
        print(f"[WIFI] already connected: {ssid}")
        return

    # Reuse an existing Windows profile first. This preserves any security details Windows already learned.
    _netsh_connect_profile(ssid)
    if _wait_device_reachable(ssid, min(6.0, timeout)):
        return

    # If no usable profile exists, create the known MTTL WPA2-PSK profile from SSID -> LGU_<suffix>.
    _install_softap_profile(ssid)
    _netsh_connect_profile(ssid)
    if not _wait_device_reachable(ssid, timeout):
        raise InstallError(f"{ssid} 연결 후 {DEVICE_IP}:{SERVICE_PORT}에 도달하지 못했습니다")


def ensure_windows_softap_connected(preferred: str | None = None, scan_timeout: float = 45.0) -> str:
    if os.name != "nt":
        raise InstallError("자동 SoftAP 연결은 Windows에서만 지원합니다")

    current = windows_current_ssid()
    if current and current.lower().startswith(SOFTAP_PREFIX.lower()) and reachable(DEVICE_IP, SERVICE_PORT, 1.0):
        if not preferred or current.lower() == preferred.lower():
            print(f"[WIFI] current MTTL SoftAP reused: {current}")
            return current

    # After OTA we already know the exact SoftAP SSID and have a usable profile.
    # Retry that profile directly so Windows Location/BSSID scan restrictions do not block reconnect.
    if preferred:
        deadline = time.time() + scan_timeout
        last_print = 0.0
        while time.time() < deadline:
            current = windows_current_ssid()
            if current and current.lower() == preferred.lower() and reachable(DEVICE_IP, SERVICE_PORT, 1.0):
                print(f"[WIFI] reconnected: {preferred}")
                return preferred
            _netsh_connect_profile(preferred)
            if _wait_device_reachable(preferred, min(4.0, max(0.5, deadline - time.time()))):
                return preferred
            if time.time() - last_print >= 8.0:
                print(f"[WIFI] {preferred} 재연결 대기 중...")
                last_print = time.time()
            time.sleep(1.0)
        raise InstallError(f"{preferred} SoftAP에 {scan_timeout:g}초 안에 다시 연결하지 못했습니다")

    deadline = time.time() + scan_timeout
    last_print = 0.0
    while time.time() < deadline:
        aps = windows_softap_scan()
        if aps:
            if len(aps) == 1:
                chosen = aps[0]
                sig = f"{chosen['signal']}%" if chosen["signal"] >= 0 else "?"
                print(f"[WIFI] MTTL SoftAP 자동 선택: {chosen['ssid']} / signal={sig}")
            else:
                print("[WIFI] MTTL SoftAP가 여러 개 발견되었습니다:")
                for i, a in enumerate(aps, 1):
                    sig = f"{a['signal']}%" if a["signal"] >= 0 else "?"
                    print(f"  {i}. {a['ssid']} / signal={sig}")
                while True:
                    raw = input(f"사용할 장치 [1-{len(aps)}]: ").strip()
                    if raw.isdigit() and 1 <= int(raw) <= len(aps):
                        chosen = aps[int(raw) - 1]
                        break
                    print("잘못된 선택입니다.")
            windows_connect_softap(chosen["ssid"])
            return chosen["ssid"]

        if time.time() - last_print >= 6.0:
            print("[WIFI] TONLY_TAP_* 검색 중...")
            last_print = time.time()
        time.sleep(2.0)

    raise InstallError(
        "TONLY_TAP_* SoftAP를 찾지 못했습니다. 장치를 SoftAP/설정 모드로 전환했는지, "
        "Windows 위치/WLAN 검색 권한이 허용됐는지 확인하세요"
    )

def prompt_wifi_credentials(ssid: str | None, password: str | None, up_mode: bool = True) -> tuple[str,str]:
    explicit_ssid = ssid is not None or bool(os.getenv("MTTL_WIFI_SSID"))
    explicit_password = password is not None or os.getenv("MTTL_WIFI_PASSWORD") is not None
    ssid=(ssid or os.getenv("MTTL_WIFI_SSID") or "").strip()
    if password is None:password=os.getenv("MTTL_WIFI_PASSWORD")
    while True:
        if not ssid:ssid=input("최종 홈 Wi-Fi SSID: ").strip()
        if password is None:password=getpass.getpass("최종 홈 Wi-Fi 암호: ")
        try:
            (validate_wifi if up_mode else validate_generic_wifi)(ssid,password)
            return ssid,password
        except InstallError as exc:
            if explicit_ssid or explicit_password or not sys.stdin.isatty():
                raise
            print(f"[입력 확인] {exc}")
            print("다시 입력하세요.")
            ssid="";password=None


def prompt_install_credentials(backend: str | None, ssid: str | None, password: str | None) -> tuple[str, str, str]:
    explicit_backend = backend is not None or bool(os.getenv("MTTL_BACKEND_IP"))
    backend=(backend or os.getenv("MTTL_BACKEND_IP") or "").strip()
    while True:
        if not backend:backend=input("Backend IPv4: ").strip()
        try:
            backend=validate_backend_ip(backend)
            break
        except InstallError as exc:
            if explicit_backend or not sys.stdin.isatty():
                raise
            print(f"[입력 확인] {exc}")
            backend=""
    ssid,password=prompt_wifi_credentials(ssid,password,True)
    print(f"[CONFIG:UP] backend={backend} / home_ssid={ssid} / home_password=<redacted>")
    return backend,ssid,password


def choose_softap_candidate(aps: list[dict]) -> str:
    if not aps:raise InstallError("SoftAP 후보가 없습니다")
    if len(aps)==1:
        chosen=aps[0];sig=f"{chosen.get('signal',-1)}%" if chosen.get('signal',-1)>=0 else "?"
        print(f"[WIFI] MTTL SoftAP 자동 선택: {chosen['ssid']} / signal={sig}")
        return chosen["ssid"]
    print("[WIFI] MTTL SoftAP가 여러 개 발견되었습니다:")
    for i,a in enumerate(aps,1):
        sig=f"{a.get('signal',-1)}%" if a.get('signal',-1)>=0 else "?"
        print(f"  {i}. {a['ssid']} / signal={sig}")
    while True:
        raw=input(f"사용할 장치 [1-{len(aps)}]: ").strip()
        if raw.isdigit() and 1<=int(raw)<=len(aps):return aps[int(raw)-1]["ssid"]
        print("잘못된 선택입니다.")


def ensure_softap_connected(preferred: str | None = None, allow_manual: bool = True) -> str:
    cur=current_ssid()
    if cur and cur.lower().startswith(SOFTAP_PREFIX.lower()) and reachable(DEVICE_IP,SERVICE_PORT,1.0):
        if not preferred or cur.lower()==preferred.lower():
            print(f"[WIFI] current MTTL SoftAP reused: {cur}")
            return cur
    try:
        if os.name=="nt":
            return ensure_windows_softap_connected(preferred,scan_timeout=30.0)
        if sys.platform.startswith("linux"):
            aps=linux_softap_scan();ssid=preferred or choose_softap_candidate(aps)
            linux_connect_softap(ssid);return ssid
        if sys.platform=="darwin":
            if preferred:
                macos_connect_softap(preferred);return preferred
            print("[WIFI] macOS 자동 스캔은 권한/OS 버전에 따라 제한될 수 있습니다.")
            raise InstallError("macOS에서 SoftAP 자동 선택을 사용할 수 없습니다")
        raise InstallError(f"지원하지 않는 OS: {sys.platform}")
    except Exception as exc:
        print(f"[WIFI] 자동 연결 실패: {exc}")
        if allow_manual:return manual_softap_fallback(preferred, reason=str(exc))
        raise


def cmd_install(
    fwr: Path, backend: str | None = None, ssid: str | None = None, password: str | None = None,
    softap: str | None = None, settle_seconds: float = 10.0, auto_connect: bool = True,
) -> None:
    backend,ssid,password=prompt_install_credentials(backend,ssid,password)
    print("\n[1/5] FWR selftest")
    cmd_selftest(fwr)
    print("\n[2/5] MTTL SoftAP 연결")
    if auto_connect:
        softap_ssid=ensure_softap_connected(softap,allow_manual=True)
    else:
        softap_ssid=manual_softap_fallback(softap)
    print("\n[3/5] OTA")
    print(f"[OTA] target SoftAP={softap_ssid} / firmware={fwr.name}")
    run_ota(fwr, softap_ssid=softap_ssid)
    print(f"\n[4/5] 펌웨어 작업 안정화: 최소 {settle_seconds:g}초")
    print("[INFO] OTA 중 SoftAP Wi-Fi 연결 자체는 유지되고 장치 서비스만 잠시 중단될 수 있습니다.")
    time.sleep(max(0.0,settle_seconds))
    if not wait_device_service(60.0):
        print("\n[WIFI] OTA 후 장치 서비스가 자동 복귀하지 않았습니다. 즉시 종료하지 않고 복구를 시도합니다.")
        try:
            softap_ssid=manual_softap_fallback(softap_ssid, reason="OTA 후 SoftAP 서비스 재접속 필요")
        except InstallError:
            msg=provisioning_pending_message(softap_ssid)
            print("\n[PROVISION PENDING]")
            print(msg)
            raise ProvisionPending(msg)
    print("\n[5/5] Provisioning")
    final_provision(backend,ssid,password,softap_ssid)
    print("\n[OK] INSTALL COMPLETE")


def cmd_install_windows(fwr: Path, backend=None, ssid=None, password=None, softap=None, settle_seconds: float=10.0) -> None:
    cmd_install(fwr,backend,ssid,password,softap,settle_seconds,auto_connect=True)

def cmd_selftest(fwr: Path) -> None:
    decoded = load_and_decode_fwr(fwr)
    wire = fwr.read_bytes()
    assert len(wire) == 327944 and len(decoded) == 327944
    assert decoded[40:40 + len(EXPECTED_MODEL)] == EXPECTED_MODEL
    assert struct.unpack_from("<I", decoded, len(decoded) - 4)[0] == (sum(decoded[:-4]) & 0xFFFFFFFF)
    assert wire[40:72] != decoded[40:72]

    # Parser/profile regression tests do not need Windows.
    sample = """
SSID 1 : HOME
    Signal : 44%
SSID 2 : TONLY_TAP_12345
    BSSID 1 : aa:bb:cc:dd:ee:ff
         신호 : 87%
"""
    parsed = parse_windows_netsh_networks(sample)
    assert parsed[1]["ssid"] == "TONLY_TAP_12345" and parsed[1]["signal"] == 87
    assert softap_password("TONLY_TAP_12345") == "LGU_12345"
    assert softap_mac_suffix("TONLY_TAP_1AED9C") == "1aed9c"
    assert softap_mac_suffix("TONLY_TAP_BAD") is None
    assert softap_mac_suffix("TONLY_TAP_12345") == "12345"
    xml = _wlan_profile_xml("TONLY_TAP_12345", "LGU_12345")
    assert "WPA2PSK" in xml and "LGU_12345" in xml

    # Exercise the exact HTTP wire payload without privileged port or MTTL hardware.
    done = threading.Event()
    srv = _OtaHTTPServer(("127.0.0.1", 0), _OtaHandler, wire, done)
    port = srv.server_address[1]
    t = threading.Thread(target=srv.serve_forever, daemon=True)
    t.start()
    try:
        with socket.create_connection(("127.0.0.1", port), 2) as s:
            s.sendall(b"GET /ota.bin HTTP/1.1\r\nHost: 192.168.1.100\r\nConnection: close\r\n\r\n")
            r = b""
            while True:
                x = s.recv(65536)
                if not x:
                    break
                r += x
        head, body = r.split(b"\r\n\r\n", 1)
        assert b"200 OK" in head and len(body) == len(wire) and body == wire and done.wait(1)
        print("SELFTEST OK", {"bytes": len(wire), "wire_body_matches_fwr": True, "wifi_parser": True})
    finally:
        srv.shutdown()
        srv.server_close()
        t.join(timeout=2)


def main() -> int:
    here = Path(__file__).resolve().parent
    ap = argparse.ArgumentParser(description="MTTL-W01 verified FWR OTA / provisioning")
    ap.add_argument("--fwr", type=Path, default=None)
    ap.add_argument("--no-log", action="store_true", help="disable logs/<command>_timestamp.log")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("preflight")
    ota=sub.add_parser("ota",help="OTA only: auto SoftAP connect -> guided retry/recovery -> TCP80 OTA")
    ota.add_argument("--softap",help="preferred TONLY_TAP_* SSID; otherwise auto scan/select")
    ota.add_argument("--manual-softap",action="store_true",help="skip automatic scan/connect and start guided SoftAP recovery")
    ota.add_argument("--version",choices=("111","110","66"),default="111",help="build target locally from pinned 1.0.105 or LG U+ 1.0.66 source before OTA")
    sub.add_parser("selftest")
    bld=sub.add_parser("build-firmware",help="download/reuse pinned 1.0.105, or use user-supplied LG U+ 1.0.66, then build exact 66/110/111")
    bld.add_argument("--version",choices=("all","111","110","66"),default="all")

    def add_provision_args(parser, up_mode: bool):
        if up_mode:parser.add_argument("--backend")
        parser.add_argument("--ssid")
        parser.add_argument("--password")
        parser.add_argument("--softap", help="preferred TONLY_TAP_* SSID; otherwise auto scan/select")
        parser.add_argument("--manual-softap", action="store_true", help="skip automatic scan/connect and start guided SoftAP recovery")

    legacy=sub.add_parser("provision", help="backward-compatible alias for provision-up")
    add_provision_args(legacy, True)
    pup=sub.add_parser("provision-up", help="save UP backend IP + Wi-Fi and verify TCP10086 attachment")
    add_provision_args(pup, True)
    pgen=sub.add_parser("provision-generic", help="stock-compatible LGAPMODE Wi-Fi provisioning; UP backend IP unchanged")
    add_provision_args(pgen, False)

    for name in ("install", "install-windows"):
        ins=sub.add_parser(name, help="locally build canonical 1.0.111 then UP provision" if name=="install" else "Windows-compatible install alias")
        ins.add_argument("--backend")
        ins.add_argument("--ssid")
        ins.add_argument("--password")
        ins.add_argument("--softap")
        ins.add_argument("--version",choices=("111","110","66"),default="111",help="source-build target when --fwr is omitted")
        ins.add_argument("--settle", type=float, default=10.0)
        if name=="install":ins.add_argument("--manual-softap", action="store_true")

    ns = ap.parse_args()
    if not ns.no_log:start_log(here, ns.cmd)
    try:
        if ns.cmd in ("preflight", "selftest") and ns.fwr is None:
            ns.fwr = choose_fwr(here)
        elif ns.cmd == "ota" and ns.fwr is None:
            ns.fwr=build_official_from_source(here,ns.version)
            print(f"[FWR] {ns.fwr.name} / locally built from user/vendor source / SHA256 verified")
        elif ns.cmd in ("install", "install-windows") and ns.fwr is None:
            ns.fwr=build_official_from_source(here,ns.version)
            print(f"[FWR] {ns.fwr.name} / locally built from user/vendor source / SHA256 verified")

        if ns.cmd == "preflight":
            print(preflight(ns.fwr))
        elif ns.cmd == "ota":
            print("\n[1/2] MTTL SoftAP 연결")
            softap_ssid=manual_softap_fallback(ns.softap) if ns.manual_softap else ensure_softap_connected(ns.softap,allow_manual=True)
            print(f"[WIFI] OTA target={softap_ssid}")
            print("\n[2/2] OTA")
            run_ota(ns.fwr, softap_ssid=softap_ssid)
        elif ns.cmd == "selftest":
            cmd_selftest(ns.fwr)
        elif ns.cmd == "build-firmware":
            rows=build_all_official_from_source(here) if ns.version=="all" else [build_official_from_source(here,ns.version)]
            for x in rows:print(f"[READY] {x.name} {hashlib.sha256(x.read_bytes()).hexdigest()}")
        elif ns.cmd in ("provision", "provision-up", "provision-generic"):
            up_mode=ns.cmd in ("provision", "provision-up")
            if up_mode:
                backend,ssid,password=prompt_install_credentials(ns.backend,ns.ssid,ns.password)
            else:
                ssid,password=prompt_wifi_credentials(ns.ssid,ns.password,False)
                print(f"[CONFIG:GENERIC] home_ssid={ssid} / home_password=<redacted> / backend_ip=UNCHANGED")
            print("\n[1/2] MTTL SoftAP 연결")
            softap_ssid=manual_softap_fallback(ns.softap) if ns.manual_softap else ensure_softap_connected(ns.softap,allow_manual=True)
            print(f"[WIFI] provisioning target={softap_ssid}")
            print("\n[2/2] "+("UP Provisioning" if up_mode else "Generic LGAPMODE Provisioning"))
            if up_mode:provision_up(backend,ssid,password,softap_ssid)
            else:provision_generic(ssid,password,softap_ssid)
        elif ns.cmd == "install-windows":
            cmd_install_windows(ns.fwr,ns.backend,ns.ssid,ns.password,ns.softap,ns.settle)
        elif ns.cmd == "install":
            cmd_install(ns.fwr,ns.backend,ns.ssid,ns.password,ns.softap,ns.settle,auto_connect=not ns.manual_softap)
        print(f"[{datetime.now():%Y-%m-%d %H:%M:%S}] === finished, exit code 0 ===")
        return 0
    except ProvisionPending:
        print(f"[{datetime.now():%Y-%m-%d %H:%M:%S}] === OTA complete, provisioning pending, exit code 3 ===")
        return 3
    except KeyboardInterrupt:
        print("ERROR: 사용자에 의해 중단되었습니다", file=sys.stderr)
        print(f"[{datetime.now():%Y-%m-%d %H:%M:%S}] === finished, exit code 130 ===")
        return 130
    except (InstallError, OSError, subprocess.SubprocessError) as exc:
        print("ERROR:", exc, file=sys.stderr)
        print(f"[{datetime.now():%Y-%m-%d %H:%M:%S}] === finished, exit code 2 ===")
        return 2


if __name__ == "__main__":
    _rc = 2
    try:
        _rc = main()
    finally:
        stop_log()
    raise SystemExit(_rc)
