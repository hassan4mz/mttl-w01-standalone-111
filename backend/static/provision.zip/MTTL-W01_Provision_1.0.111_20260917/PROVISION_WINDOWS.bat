@echo off
rem Backward-compatible alias: legacy PROVISION_WINDOWS.bat means UP provisioning.
call "%~dp0PROVISION_UP_WINDOWS.bat"
exit /b %ERRORLEVEL%
