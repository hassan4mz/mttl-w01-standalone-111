@echo off
setlocal
cd /d "%~dp0"
chcp 65001 >nul 2>nul

net session >nul 2>nul
if errorlevel 1 (
  echo Requesting Administrator privileges...
  powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)

where python >nul 2>nul
if errorlevel 1 (
  echo ERROR: Python was not found in PATH.
  pause
  exit /b 1
)

echo ============================================================
echo MTTL-W01 AUTO INSTALLER
echo   pinned 1.0.105 download/cache OR user-supplied LG U+ 1.0.66 ^> exact 1.0.111 build ^> selftest
echo   ^> TONLY_TAP auto-connect ^> OTA
echo   ^> minimum 10 sec settle ^> service wait ^> UP Provision
echo   Wi-Fi failure enters guided recovery: connect TONLY_TAP, Enter retry x2, then y/n.
echo   Logs: .\logs\install_*.log
echo ============================================================
echo.

python mttl_setup.py install
set RC=%ERRORLEVEL%


echo.
if "%RC%"=="3" (
  echo OTA COMPLETED, BUT PROVISIONING IS PENDING.
  echo Put the device into SoftAP mode again with the power button,
  echo connect this PC to TONLY_TAP_*, then run PROVISION_WINDOWS.bat.
  echo Do NOT run OTA again.
  echo See .\logs\install_*.log
  pause
  exit /b 3
)
if not "%RC%"=="0" (
  echo INSTALL FAILED. Error code: %RC%
  echo See .\logs\install_*.log
) else (
  echo INSTALL COMPLETE.
  echo See .\logs\install_*.log
)
pause
exit /b %RC%
