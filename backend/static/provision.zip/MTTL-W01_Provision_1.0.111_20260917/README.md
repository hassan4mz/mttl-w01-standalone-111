# MTTL-W01 PC Provision / OTA Tool

## 실행 모드

모든 OTA는 **PC TCP/80**을 그대로 사용합니다. 66/110은 TCP80 고정이고 111은 TCP49217 실패 시 TCP80 fallback이므로 한 경로로 모두 처리됩니다.

- `BUILD_FIRMWARE_WINDOWS.bat`
  - 공개 source **1.0.105** 자동 다운로드를 시도하고 SHA256으로 검증
  - 다운로드가 안 되면 사용자가 별도 확보한 exact **1.0.105 또는 LG U+ 1.0.66** FWR을 이 툴 폴더에 넣어 사용
  - exact 1.0.66 / 1.0.110 / 1.0.111을 사용자 PC에서 로컬 생성
  - 최종 고정 SHA256까지 검증
- `OTA_WINDOWS.bat`
  - OTA만 수행
  - 기본 1.0.111 로컬 생성 → TONLY_TAP 자동 검색/연결 → 실패 시 안내형 복구(Enter 재확인 2회 → 마지막 y/n) → TCP80 OTA
  - 홈 Wi-Fi/Backend provisioning은 하지 않음
- `PROVISION_GENERIC_WINDOWS.bat`
  - Generic provisioning만 수행
  - TONLY_TAP 자동 검색/연결 → 안내형 복구/재시도 → LGAPMODE cmd101/102
  - 저장된 UP Backend IP는 변경하지 않음
- `PROVISION_UP_WINDOWS.bat` (`PROVISION_WINDOWS.bat` 별칭)
  - UP provisioning만 수행
  - TONLY_TAP 자동 검색/연결 → 안내형 복구/재시도 → `up:ip` + `up:connect`
  - cmd103 Device Info에서 exact MAC을 먼저 읽어 Backend attach 검증에 사용
  - exact MAC을 못 읽으면 SSID suffix는 보조 힌트로만 사용하며, suffix가 6자리가 아니어도 명령 성공을 실패로 뒤집지 않음
- `INSTALL_WINDOWS.bat`
  - **1.0.105 자동 받기 또는 사용자가 넣은 1.0.105/LG U+ 1.0.66 검증 → 1.0.111 생성 → selftest → SoftAP 자동 연결/안내형 복구 → OTA → 안정화/재연결 복구 → UP provisioning** 전체 수행
  - 배포 ZIP에는 FWR 바이너리가 들어 있지 않음. source를 확보하지 못하면 생성/OTA를 진행하지 않음


## FWR 미포함 배포 원칙

이 PC 툴 배포 ZIP에는 `.fwr` 파일을 포함하지 않습니다. 툴은 사용자의 환경에서만 펌웨어를 준비합니다.

source 우선순위:

1. 툴 폴더의 exact 1.0.105 또는 LG U+ 1.0.66 FWR 검색 및 SHA 검증
2. 없으면 1.0.105 vendor URL 자동 다운로드 시도
3. 다운로드 실패 시, 사용자가 별도 확보한 다음 중 하나를 **툴과 같은 폴더**에 넣고 다시 실행
   - `MTTL-W01_V1.0.105.fwr` — SHA256 `f78aee903d392f2b8470c845d9e76c33d91fd1da57e6c7e714cbedc9edaefa`
   - LG U+ 1.0.66 FWR — 파일명은 달라도 되며 SHA256 `d780b578af69d52f3a05191a8e7d91a20e05085a912722327481cd5663682c04`이면 인식

source가 맞지 않으면 파일명과 관계없이 거부합니다. 생성된 66/110/111 FWR은 사용자의 로컬 폴더에만 만들어집니다.

## SoftAP 연결 복구 흐름

자동 검색/연결이 실패해도 바로 종료하지 않습니다. 사용자가 SoftAP SSID를 직접 타이핑할 필요도 없습니다.

1. 가능한 경우 저장된 프로필/SoftAP 검색으로 자동 연결을 다시 시도합니다.
2. Wi-Fi 설정에서 `TONLY_TAP_*`에 연결한 뒤 **Enter**를 누르면 현재 SSID와 `192.168.1.1:30300`을 다시 확인합니다.
3. 실패하면 한 번 더 Wi-Fi 연결을 확인하도록 안내하고 **Enter**로 두 번째 검사를 합니다.
4. 그래도 감지되지 않으면 `y/n`으로 실제 OTA/Provision 단계까지 한 번 진행할지, 안전하게 종료할지 선택합니다. `y`를 선택해도 FWR checksum, TCP/80 bind, 장치 ACK/응답 검증은 생략하지 않습니다.
5. OTA 후 SoftAP 서비스 복귀가 늦는 경우도 같은 복구 흐름을 거친 뒤 Provisioning을 계속 시도합니다.

홈 Wi-Fi SSID/Backend IPv4를 콘솔에서 잘못 입력한 경우에도 즉시 프로그램을 끝내지 않고 다시 입력하도록 안내합니다. 반대로 OTA ACK 이후처럼 장치 상태 변경 여부가 불명확한 mutation은 자동 재전송하지 않습니다.

## Python 명령

```text
python mttl_setup.py build-firmware --version all
python mttl_setup.py build-firmware --version 111
python mttl_setup.py ota
python mttl_setup.py ota --version 111
python mttl_setup.py ota --softap TONLY_TAP_xxxxxx
python mttl_setup.py ota --manual-softap
python mttl_setup.py provision-generic
python mttl_setup.py provision-up
python mttl_setup.py install --version 111
python mttl_setup.py install --version 110
python mttl_setup.py install --version 66
```

별도 FWR은 전역 인자로 명시할 수 있습니다.

```text
python mttl_setup.py --fwr custom.fwr ota
python mttl_setup.py --fwr custom.fwr install
```

`--fwr`은 subcommand **앞**에 둡니다.


## 펌웨어 버전 차이

- **1.0.66** — LG U+ stock-compatible 기준판.
- **1.0.110 (66 대비)** — UP TCP10086 로컬 백엔드, 물리 버튼 ON/OFF 즉시 `up:event:onoff` 보고, 정상 Wi-Fi+UP 연결 시 주황 상태 LED 소등. Child Lock 없음.
- **1.0.111 (110 대비)** — All+Outlet1..4 물리 짧은 누름 Child Lock과 Flash 영속 저장 추가. 110의 event/LED 동작 유지. SoftAP 0.1.55. OTA는 TCP49217 우선, connect 실패 시 TCP80 fallback.

실물 MTTL-W01 메인 SoC는 **Realtek RTL8711AF**이며, 확인된 Flash JEDEC ID는 **`C2 20 14`** (Macronix 8-Mbit/1-MiB, MX25L8005/MX25L8006E-compatible)입니다.

## 공식 결과 SHA256

- 1.0.111: `7766d8c309ea77361a31b2af0c710ee24d05d076a48ecc0c8ee9b627bb288dfb`
- 1.0.110: `318f44567cd90613a3a485a66bb398c80bc60c891699772d438c9cfd6cb33059`
- 1.0.66: `d780b578af69d52f3a05191a8e7d91a20e05085a912722327481cd5663682c04`
- source 1.0.105: `f78aee903d392f2b8470c845d9e76c33d91fdcf1da57e6c7e714cbedc9edaefa`

Vendor의 `firmware1.0.115` 디렉터리에도 파일은 `MTTL-W01_V1.0.105.fwr` 이름으로 제공되며 기존 105 경로와 byte-for-byte 동일합니다. `MTTL-W01_V1.0.115.fwr`는 404이므로, 도구는 115 디렉터리 경로를 우선 시도하되 **source identity는 1.0.105의 고정 SHA256**으로 판정합니다.
