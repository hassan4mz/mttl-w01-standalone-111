@echo off
setlocal
cd /d "%~dp0"
chcp 65001 >nul 2>nul
net session >nul 2>nul
if errorlevel 1 (
  echo Requesting Administrator privileges for TCP/80...
  powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)
where python >nul 2>nul
if errorlevel 1 (echo ERROR: Python was not found in PATH.& pause& exit /b 1)
echo ============================================================
echo MTTL-W01 OTA ONLY
 echo   1.0.105/1.0.66 source -^> exact 1.0.111 local build -^> SoftAP -^> TCP/80 OTA
 echo   Auto-connect failure -^> guided Wi-Fi recovery / Enter retry / final y-n choice
 echo   No provisioning is performed.
echo ============================================================
echo.
python mttl_setup.py ota --version 111
set RC=%ERRORLEVEL%
echo.
if "%RC%"=="0" (echo OTA TRANSFER COMPLETE.) else (echo OTA FAILED. Error code: %RC%)
pause
exit /b %RC%
