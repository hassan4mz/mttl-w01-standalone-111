#!/usr/bin/env python3
"""Neutral entry point for MTTL-W01 OTA + generic/UP provisioning.

mttl_up_setup.py is retained for backward compatibility.
"""
import mttl_up_setup as tool

if __name__=='__main__':
    rc=2
    try:
        rc=tool.main()
    finally:
        tool.stop_log()
    raise SystemExit(rc)
