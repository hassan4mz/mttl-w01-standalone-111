@echo off
setlocal
cd /d "%~dp0"
chcp 65001 >nul 2>nul
where python >nul 2>nul
if errorlevel 1 (echo ERROR: Python was not found in PATH.& pause& exit /b 1)
echo ============================================================
echo MTTL-W01 UP PROVISIONING
echo   - saves UP backend IP with up:ip
echo   - applies home Wi-Fi with up:connect
echo   - verifies actual UP backend TCP10086 attachment
echo   - TONLY_TAP auto scan/connect; guided Enter retry/recovery on failure
echo ============================================================
echo.
python mttl_setup.py provision-up
set RC=%ERRORLEVEL%
echo.
if "%RC%"=="0" (echo UP PROVISION COMPLETE.) else (echo UP PROVISION FAILED. Error code: %RC%)
pause
exit /b %RC%
