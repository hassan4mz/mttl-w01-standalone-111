@echo off
setlocal
cd /d "%~dp0"
chcp 65001 >nul 2>nul
where python >nul 2>nul
if errorlevel 1 (echo ERROR: Python was not found in PATH.& pause& exit /b 1)
echo ============================================================
echo MTTL-W01 GENERIC PROVISIONING
echo   - applies home Wi-Fi with stock-compatible LGAPMODE 101/102
echo   - DOES NOT modify saved UP backend IP
echo   - TONLY_TAP auto scan/connect; guided Enter retry/recovery on failure
echo ============================================================
echo.
python mttl_setup.py provision-generic
set RC=%ERRORLEVEL%
echo.
if "%RC%"=="0" (echo GENERIC PROVISION COMMAND ACCEPTED.) else (echo GENERIC PROVISION FAILED. Error code: %RC%)
pause
exit /b %RC%
