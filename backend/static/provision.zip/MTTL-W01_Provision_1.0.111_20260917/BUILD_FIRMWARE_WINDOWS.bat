@echo off
setlocal
cd /d "%~dp0"
chcp 65001 >nul 2>nul
where python >nul 2>nul
if errorlevel 1 (echo ERROR: Python was not found in PATH.& pause& exit /b 1)
echo ============================================================
echo MTTL-W01 OFFICIAL FIRMWARE BUILDER
 echo   Download/reuse pinned 1.0.105, or use user-supplied LG U+ 1.0.66
 echo   Build exact 1.0.66 / 1.0.110 / 1.0.111
 echo   Final SHA256 is verified for every output.
echo ============================================================
echo.
python mttl_setup.py build-firmware --version all
set RC=%ERRORLEVEL%
echo.
if "%RC%"=="0" (echo FIRMWARE BUILD COMPLETE.) else (echo BUILD FAILED. Error code: %RC%)
pause
exit /b %RC%
