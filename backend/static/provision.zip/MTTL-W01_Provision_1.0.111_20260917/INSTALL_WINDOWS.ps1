$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot

$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($identity)
$isAdmin = $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Write-Host 'Requesting Administrator privileges...'
    $arg = "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""
    $p = Start-Process powershell.exe -Verb RunAs -ArgumentList $arg -Wait -PassThru
    exit $p.ExitCode
}

$python = Get-Command python -ErrorAction SilentlyContinue
if (-not $python) {
    Write-Host 'ERROR: Python was not found in PATH.'
    exit 1
}

Write-Host '============================================================'
Write-Host 'MTTL-W01 AUTO INSTALLER'
Write-Host '  FWR select -> TONLY_Tap auto-connect -> OTA'
Write-Host '  -> minimum 10 sec settle -> guided SoftAP recovery if needed -> Provision'
Write-Host '  Logs: .\logs\install_*.log'
Write-Host '============================================================'

& python mttl_setup.py install
$rc = $LASTEXITCODE

if ($rc -ne 0) {
    Write-Host "INSTALL FAILED. Error code: $rc"
    Write-Host 'See .\logs\install_*.log'
} else {
    Write-Host 'INSTALL COMPLETE.'
    Write-Host 'See .\logs\install_*.log'
}
exit $rc
